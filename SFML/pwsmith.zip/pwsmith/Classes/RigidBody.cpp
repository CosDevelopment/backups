
#include "SFML/Graphics.hpp"
#include "./Headers/RigidBody.h"
//TODO ignore this . this is a WIP
RigidBody::RigidBody(){


}